
#include <stdio.h>

void displayPrompt(void);

void displayPrompt()
{	
    /* Display a "$ " Prompot */
    printf("$ ");
}
